Skantastic Liquid-Glass Website (Static, Vercel)

Includes:
- SEO meta tags + keywords
- Schema: Organization, WebSite, MobileApplication, FAQPage
- robots.txt + sitemap.xml
- OG image + favicon
- 5 screenshots embedded

DO THIS:
1) Replace App Store placeholder:
   Search for idYOURAPPID in index.html and replace with your real App Store link once approved.

2) Deploy to Vercel:
   Replace files in your current Vercel static project and redeploy.
